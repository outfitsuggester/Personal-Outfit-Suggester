exports.uploadImage = async (req, res) => {
    const imagePath = req.file.path;
    const user = await User.findById(req.user.id);
    user.image = imagePath;
    await user.save();
    res.json({ image: imagePath });
  };
  