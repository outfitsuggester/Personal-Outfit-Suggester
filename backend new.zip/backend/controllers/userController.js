exports.updateSizes = async (req, res) => {
    const { height, chest, waist, hips } = req.body;
    const user = await User.findById(req.user.id);
    user.sizes = { height, chest, waist, hips };
    await user.save();
    res.json({ message: 'Sizes updated', sizes: user.sizes });
  };
  